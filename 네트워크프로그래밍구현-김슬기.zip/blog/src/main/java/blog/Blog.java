package blog;

public class Blog {
	private int write_id;
	private String write_title;
	private String write_content;
	private String write_date;
	
	public int getWrite_id() {
		return write_id;
	}
	public void setWrite_id(int write_id) {
		this.write_id = write_id;
	}
	public String getWrite_title() {
		return write_title;
	}
	public void setWrite_title(String write_title) {
		this.write_title = write_title;
	}
	public String getWrite_content() {
		return write_content;
	}
	public void setWrite_content(String write_content) {
		this.write_content = write_content;
	}
	public String getWrite_date() {
		return write_date;
	}
	public void setWrite_date(String write_date) {
		this.write_date = write_date;
	}
}
